import java.io.IOException;

public class Ejecutar {
    private Info info;
    private String build;

    public Ejecutar() {
        info = new Info();
        info.setSlash();
        info.setDirectorio();
        info.setPath();
        this.build = info.getBuild();
    }

    public String getBuild() {
        return build;
    }

    public void execProgram() {
        Process p;
        String[] command1 = {"cmd.exe", "/c", 
                            "cd \""+build+"\""};

        try {
            p = Runtime.getRuntime().exec(command1);
            System.out.println("Compilado en: "+build);
        } catch (IOException e) { 
            e.printStackTrace(); 
        } 

        String[] command2 = {"cmd.exe", "/c",
                            "java -cp \".;..\\dep\\postgresql-42.7.3.jar\" Main"};
        
        try {
            p = Runtime.getRuntime().exec(command2);
            System.out.println("Compilado en: "+build);
        } catch (IOException e) { 
            e.printStackTrace(); 
        }
    }

    public static void main(String[] args) {
        Ejecutar e = new Ejecutar();
        System.out.println("Build: "+e.getBuild());

    }
}
