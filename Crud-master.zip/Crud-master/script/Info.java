import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class Info{
    private String origen, src, build, dep, slash;
    private String nombre = "Crud";
    private String filename = "info.xml";

    public Info(){
    }

    public void setSlash() {
        String os = System.getProperty("os.name");
        if (os.contains("indows")) {
            this.slash = "\\";
        } else {
            this.slash = "/";
        }
    }
    
    public String getOrigen(){
        return origen;
    }

    public String getSrc(){
        return src;
    }

    public String getBuild(){
        return build;
    }

    public String getDep(){
        return dep;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public void setPath() {
        this.src = origen+slash+"src";
        this.build = origen+slash+"build";
        this.dep = origen+slash+"dep";
    }

    public void createFile(){
        try {
            File file = new File(filename);
            if (file.createNewFile()) {
              System.out.println("Archivo '"+file.getName()+"' creado  en: " + origen);
            } else {
              System.out.println("El archivo 'info.xml' ya existe.");
            }
          } catch (IOException e) {
            System.out.println("No se pudo crear el archivo");
            e.printStackTrace();
        }
    }
    
    public boolean setDirectorio() {
        String pwd = System.getProperty("user.dir");
        boolean cont = pwd.contains(this.nombre);
        if (cont == true) {
            setOrigen(pwd);
            return true;
        } else {
            System.out.println("No te encuentras en la carpeta del proyecto.");
            System.out.println("Muevete a la carpeta del projecto y vuelve a ejecutar el programa.");
            return false;
        }
    }

    // Añade la ruta para cada etiqueta del archivo info.xml
    // Si se llama cuando el archivo ya tiene valores, estos se reescriben
    public void addValor(String origen, String build, String src, String dep) {
        // ¿Escribi el contenido del xml en una variable? Si.
        String xmlInput = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" 
            + "<directorios>\n"
            + "\t<origen>"+origen+"</origen>\n"
            + "\t<build>"+build+"</build>\n"
            + "\t<src>"+src+"</src>\n"
            + "\t<dep>"+dep+"</dep>\n"
            + "</directorios>";

        try {
            FileWriter myWriter = new FileWriter(filename);
            myWriter.write(xmlInput);
            myWriter.close();
            System.out.println("Archivo 'info.xml' listo.");
        } catch (IOException e) {
            System.out.println("Error!");
            e.printStackTrace();
        }
    }

    public void execAll(){
        setSlash();
        setDirectorio();
        createFile();
        setPath();
        String o = getOrigen();
        String s = getSrc();
        String b = getBuild();
        String d = getDep();
        addValor(o, s, b, d);
    }
    
    // Retorna el valor de un directorio indicado en 'info.xml'
    public String getValue(String tag) {
        String value = "";
        try {
            File inputFile = new File("info.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();

            NodeList tagList = doc.getElementsByTagName(tag);
            
            if (tagList.getLength() > 0) {
                value = tagList.item(0).getTextContent();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return value;
    }

}   