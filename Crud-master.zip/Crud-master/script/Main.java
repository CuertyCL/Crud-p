import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Info info = new Info();
        Compilar comp = new Compilar();
        Ejecutar ejec = new Ejecutar();
        Scanner scan = new Scanner(System.in);

        info.setPath();
        info.setDirectorio();

        System.out.println("Elige pibe.");
        System.out.println("1. Compilar");
        System.out.println("2. Ejecutar");
        System.out.println("3. Compilar y Ejecutar");

        System.out.print(": ");
        int op = scan.nextInt();

        switch (op) {
            case 1:
                comp.genSourcesWin();
                comp.genDepWin();
                comp.compSourceWin();
                break;
            case 2:
                ejec.execProgram();
                break;
            case 3:
                comp.genSourcesWin();
                comp.genDepWin();
                comp.compSourceWin();
                ejec.execProgram();
                
                break;
            default:
                System.out.println("Elige una opcion valida.");
                break;
            }
        scan.close();
    }
}
