import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Compilar {
    private Info info;
    private String origen, src, build, dep;

    public Compilar() {
        info = new Info();
        info.setSlash();
        info.setDirectorio();
        info.setPath();
        this.origen = info.getOrigen();
        this.src = info.getSrc();
        this.build = info.getBuild();
        this.dep = info.getDep();
    }

    public void genSourcesWin() {
        Process p;
        String[] command = {"cmd.exe", "/c", 
                            "dir \""+src+"\" /b /s *.java | findstr /e .java | sort /unique > \""+origen+"\\sources.txt\""};
        try {
            p = Runtime.getRuntime().exec(command);
            System.out.println("Creado el archivo sources.txt en: "+origen);
        } catch (IOException e) { 
            e.printStackTrace();
        }
    }

    public void genDepWin() {
        Process p;
        String[] command1 = {"cmd.exe", "/c", 
                            "dir \""+dep+"\" /b /s *.jar | findstr /e .jar | sort /unique > \""+origen+"\\dep.txt\""};
        try {
            p = Runtime.getRuntime().exec(command1);
            System.out.println("Creado el archivo dep.txt en: "+origen);
        } catch (IOException e) {
            e.printStackTrace(); 
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(origen+"\\dep.txt", true))) {
            // Escribir la nueva línea en el archivo
            writer.write(build);
            writer.newLine(); // Agregar un salto de línea después de la nueva línea
            System.out.println("Nueva línea añadida al archivo.");
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }

    public void compSourceWin(){
        Process p;
        String[] command = {"cmd.exe", "/c", 
                            "javac -cp \"@"+origen+"\\dep.txt\" -d \""+build+"\" \"@"+origen+"\\sources.txt\""};

        try {
            p = Runtime.getRuntime().exec(command);
            System.out.println("Compilado en: "+build);
        } catch (IOException e) { 
            e.printStackTrace(); 
        } 
    }
}

