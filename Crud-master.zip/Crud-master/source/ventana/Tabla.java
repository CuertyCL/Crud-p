package ventana;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/* 
 *
 * La clase "Tabla" se centra en definir lo que vendria siendo el contenido de la tabla en si.
 * 
 * Cualquier cambio al contenido de la tabla debe ser aqui.
 * 
 * La creación de la tabla será en la clase "Ventana".
 * 
 */

public class Tabla{
    // Datos temporales, despues se reemplazaran con los datos de las tablas
    private String[] nomColumn = {"Columna 1", "Columna 2", "Columna 3", "Columna 4",};
    private Object[][] datos = {
        {"Dato 11", "Dato 12", "Dato 13", "Dato 14"},
        {"Dato 21", "Dato 22", "Dato 23", "Dato 24"},
        {"Dato 31", "Dato 32", "Dato 33", "Dato 34"},
        {"Dato 41", "Dato 42", "Dato 43", "Dato 44"}};
    
    
    private final DefaultTableModel model = new DefaultTableModel();
    
    public void setDatos(Object[][] datos) {
        this.datos = datos;
    }

    public void setNomColumn(String[] nomColumn) {
        this.nomColumn = nomColumn;
    }
    
}
