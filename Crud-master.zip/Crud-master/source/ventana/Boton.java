package ventana;

import java.awt.Dimension;
import javax.swing.JButton;

public class Boton extends JButton{
    public int x = 120;
    public int y = 30;
    
    public Boton(String titulo) {
        super(titulo);
        setPreferredSize(new Dimension(this.x, this.y));
        setFocusable(false);
    }

    public Boton(String titulo, int x, int y) {
        super(titulo);
        setPreferredSize(new Dimension(x, y));
        setFocusable(false);
    }

    

    public void giveMessage() {
        System.out.println("Wena po, como andamios");
    }
}
