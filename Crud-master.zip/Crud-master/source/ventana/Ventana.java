package ventana;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Ventana extends JFrame implements ActionListener{
    private JFrame ventana;
    private Boton b1, b2, b3, b4, b5, b6, b7, b8, b9;
    private Tabla t1;

    public Ventana() {
        iniciar();
    }

    public void iniciar() {
        ventana = new JFrame("Ventana de pruieba");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(800, 600);
        ventana.setLayout(new BorderLayout(0, 23));
        ventana.setLocationRelativeTo(null);

        JPanel p1 = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 15));
        p1.setPreferredSize(new Dimension(100, 50));
        //p1.setBackground(Color.RED);
        JPanel p2 = new JPanel(new BorderLayout(20, 0));
        p2.setPreferredSize(new Dimension(100, 100));
        //p2.setBackground(Color.GREEN);
        JPanel p3 = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        p3.setPreferredSize(new Dimension(100, 50));
        //p3.setBackground(Color.BLUE);
        JPanel p4 = new JPanel(new FlowLayout(FlowLayout.LEADING, 13, 25));
        p4.setPreferredSize(new Dimension(150, 50));
        //p4.setBackground(Color.BLUE);
        JPanel p5 = new JPanel(new FlowLayout(FlowLayout.LEADING, 13, 25));
        p5.setPreferredSize(new Dimension(150, 50));
        //p5.setBackground(Color.BLUE);

        // ComboBox
        String[] lista = {"-- Selecciona una tabla --","Tabla 1","Tabla 2","Tabla 3"};
        JComboBox caja = new JComboBox(lista);
        
        caja.setSelectedIndex(0);
        caja.setPreferredSize(new Dimension(300, 30));

        p1.add(caja);

        // Tabla
        
        String[] nomColumn = {"Columna 1", "Columna 2", "Columna 3", "Columna 4",};
        Object[][] datos = {
        {"Dato 11", "Dato 12", "Dato 13", "Dato 14"},
        {"Dato 21", "Dato 22", "Dato 23", "Dato 24"},
        {"Dato 31", "Dato 32", "Dato 33", "Dato 34"},
        {"Dato 41", "Dato 42", "Dato 43", "Dato 44"}};
        JTable t1 = new JTable(datos, nomColumn);
        //JScrollPane sp = new JScrollPane(t1);
        //sp.setViewportView(t1);
        p2.add(t1, BorderLayout.CENTER);
        p2.add(t1.getTableHeader(), BorderLayout.NORTH);
        //ventana.add(new JScrollPane(t1), BorderLayout.SOUTH);

        


        // Botones
        b1 = new Boton("Nuevo Registro");
        b1.addActionListener(this);
        b2 = new Boton("Modificar Registro");
        b2.addActionListener(this);
        b3 = new Boton("Eliminar Registro");
        b3.addActionListener(this);

        p3.add(b1);
        p3.add(b2);
        p3.add(b3);

        b4 = new Boton("Nueva Tabla");
        b5 = new Boton("Modificar Tabla");
        b6 = new Boton("Eliminar Tabla");

        p4.add(b4, BorderLayout.CENTER);
        p4.add(b5, BorderLayout.CENTER);
        p4.add(b6, BorderLayout.CENTER);

        b7 = new Boton("Recargar");
        b8 = new Boton("Filtrar");
        b9 = new Boton("Consulta");

        p5.add(b7, BorderLayout.CENTER);
        p5.add(b8, BorderLayout.CENTER);
        p5.add(b9, BorderLayout.CENTER);



        ventana.add(p1, BorderLayout.NORTH);
        ventana.add(p2, BorderLayout.CENTER);
        ventana.add(p3, BorderLayout.SOUTH);
        ventana.add(p4, BorderLayout.EAST);
        ventana.add(p5, BorderLayout.WEST);
    }

    public void show() {
        ventana.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==b1) {
            b1.giveMessage();
            confirmar();
        }
    }

    public static void confirmar() {
        String opciones[] = {"Si", "No"};
        int res = JOptionPane.showOptionDialog(null, "¿Desea confirmar la operación?", "¿Confirmar?", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, 0);
        System.out.println(res);
    }
}
