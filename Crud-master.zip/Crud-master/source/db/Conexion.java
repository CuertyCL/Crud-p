package db;

import java.sql.*;
import javax.swing.*;
import ventana.*;

public class Conexion{

    private String user = " ", passwd = " ", db = " ";
    private String port = "5432";
    private String url = "jdbc:postgresql://localhost:"+port+"/";

    public Conexion() {
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    } 

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    } 

    public String getDB() {
        return db;
    }

    public void setDB(String db) {
        this.db = db;
    }

    public void generarConexion() {
        Connection conn = null;

        url = url + db;

        try {
            conn = DriverManager.getConnection(url, user, passwd);
            System.out.println("Conectado!");
            JOptionPane.showMessageDialog(null, "Se pudo conectar a la base de datos!", "Conectado", JOptionPane.INFORMATION_MESSAGE);
            System.out.println(url);
            
            conn.close();
            user = passwd = db = "";
            url = "jdbc:postgresql://localhost:"+port+"/";
            Ventana ventana = new Ventana();
            ventana.show();
        } catch (SQLException e) {
            System.out.println("Error");
            JOptionPane.showMessageDialog(null, "No se pudo conectar a la base de datos!", "Error", JOptionPane.ERROR_MESSAGE);
            user = passwd = db = " ";
            url = "jdbc:postgresql://localhost:"+port+"/";

            System.out.println(url);
        }
    }
}
