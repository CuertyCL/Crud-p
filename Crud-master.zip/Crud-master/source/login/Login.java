package login;

import javax.swing.*;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.BorderLayout;

import db.Conexion;

public class Login extends JFrame implements ActionListener{

    private String os = System.getProperty("os.name");
    private int os_lenght = os.trim().length();

    private Conexion sql = new Conexion();
    private Contenedor c1, c2, c3;
    private JButton button;

    public Login() {
        setPropiedades();
        inicializar();
    }

    public void setPropiedades() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(new Dimension(400,400));
        this.setLocationRelativeTo(null);
        this.setResizable(false);
    }

    public void inicializar() {

        setDefaultLookAndFeelDecorated(true);

        try {
            if (os_lenght>=7) {
                UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            } else {
                UIManager.setLookAndFeel("com.sun.java.swing.plaf.gtk.GTKLookAndFeel");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        JPanel p1 = new JPanel(new GridLayout(4,1));
        JPanel p2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 25, 20));
        JPanel p3 = new JPanel();
        p3.setPreferredSize(new Dimension(400, 50));

        JLabel titulo = new JLabel("INICIAR SESIÓN");
        titulo.setFont(new Font("Consolas", Font.BOLD, 20));
        p3.add(titulo, BorderLayout.CENTER);

        c1 = new Contenedor("Usuario:");
        c2 = new Contenedor("Contraseña:", true);
        c3 = new Contenedor("DataBase: ");

        p1.add(c1, BorderLayout.WEST);
        p1.add(c2, BorderLayout.WEST);
        p1.add(c3, BorderLayout.WEST);


        button = new JButton("Iniciar Sesión");
        button.setPreferredSize(new Dimension(125, 30));
        button.addActionListener(this);
        p2.add(button);

        this.add(p1);
        this.add(p2, BorderLayout.SOUTH);
        this.add(p3, BorderLayout.NORTH);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==button) {
            sql.setUser(c1.getTexto());
            sql.setPasswd(c2.getTexto());
            sql.setDB(c3.getTexto());

            sql.generarConexion();
        }
    }



    public static void main(String[] args) {
        Login ventana = new Login();
        ventana.setVisible(true);
    }
}
