package login;

import java.awt.Dimension;
import javax.swing.*;

public class Contenedor extends JPanel{
    private JPanel p2 = new JPanel();
    private JTextField textfiel;
    private JPasswordField passwd;
    private JLabel label;
    private String texto;
    private boolean isPasswd = false;

    public Contenedor(String titulo, boolean isPasswd){
        setIsPasswd(isPasswd);
        this.addComponentes(titulo);
    }

    public Contenedor(String titulo){
        this.addComponentes(titulo);
    }

    public void setIsPasswd(boolean isPasswd) {
        this.isPasswd = isPasswd;
    }

    public boolean getIsPasswd() {
        return isPasswd;
    }

    public void addComponentes(String titulo) {
        p2.setLayout(new BoxLayout(p2, BoxLayout.Y_AXIS));

        label = new JLabel(titulo);
        p2.add(label);

        if (getIsPasswd()==true) {
            passwd = new JPasswordField();
            passwd.setPreferredSize(new Dimension(150, 35));
            p2.add(passwd);
        } else { 
            textfiel = new JTextField();
            textfiel.setPreferredSize(new Dimension(150, 35));
            p2.add(textfiel);
        }    

        this.add(p2);
    }

    public String getTexto() {
        if (getIsPasswd()==false){
            texto = textfiel.getText();
            return texto;
        } else {
            texto = String.valueOf(passwd.getPassword());
            return texto;
        }
    }
}
